import glob
import json
import os
import sys
from collections import defaultdict


def latest_probe_log():
    candidates = glob.glob(os.path.join("logs", "pmdg_interaction_probe_*.ndjson"))
    if not candidates:
        return ""
    return max(candidates, key=os.path.getmtime)


def load_records(path):
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except Exception:
                pass
    return records


def analyze(path):
    records = load_records(path)
    markers = [r for r in records if r.get("type") == "marker"]
    controls = [r for r in records if r.get("type") == "control_echo" and int(r.get("event", 0) or 0) != 0]
    changes = [r for r in records if r.get("type") == "derived_change"]

    lines = [
        "PMDG Interaction Probe Analysis",
        f"Source: {os.path.abspath(path)}",
        f"Records: {len(records)}",
        f"Markers: {len(markers)}",
        f"Control echoes: {len(controls)}",
        f"Derived numeric changes: {len(changes)}",
        "",
    ]

    if markers:
        lines.append("Markers")
        for r in markers:
            lines.append(f"- {r.get('t_rel', 0):>8}s  {r.get('label', '')}")
        lines.append("")

    lines.append("Control Echoes")
    if controls:
        for r in controls[:300]:
            event = int(r.get("event", 0) or 0)
            lines.append(
                f"- {r.get('t_rel', 0):>8}s  event={event} "
                f"name={r.get('event_name', '') or '-'} param={r.get('param', '')}"
            )
        if len(controls) > 300:
            lines.append(f"- ... {len(controls) - 300} more")
    else:
        lines.append("- No non-zero PMDG_CONTROL echo was observed. Use derived changes below.")
    lines.append("")

    grouped = defaultdict(list)
    for r in changes:
        grouped[r.get("field", "unknown")].append(r)

    lines.append("Derived Changes")
    if grouped:
        for field, rows in sorted(grouped.items()):
            deltas = [float(r.get("delta", 0) or 0) for r in rows]
            rates = [abs(float(r.get("rate_per_sec", 0) or 0)) for r in rows]
            lines.append(
                f"- {field}: count={len(rows)} delta_sum={sum(deltas):.3f} "
                f"max_abs_rate={max(rates):.3f}/s avg_abs_rate={(sum(rates) / len(rates)):.3f}/s"
            )
    else:
        lines.append("- No numeric changes observed.")
    lines.append("")

    if changes:
        lines.append("Top Rate Samples")
        for r in sorted(changes, key=lambda x: abs(float(x.get("rate_per_sec", 0) or 0)), reverse=True)[:40]:
            lines.append(
                f"- {r.get('t_rel', 0):>8}s {r.get('field')} "
                f"{r.get('old')} -> {r.get('new')} delta={r.get('delta')} "
                f"dt={r.get('dt')} rate={r.get('rate_per_sec')}/s"
            )

    report_path = os.path.splitext(path)[0] + "_analysis.txt"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return report_path, "\n".join(lines)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else latest_probe_log()
    if not path:
        print("No probe log found under logs/pmdg_interaction_probe_*.ndjson", file=sys.stderr)
        return 2
    report_path, text = analyze(path)
    print(text)
    print("")
    print(f"Analysis written: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
