param(
    [Parameter(Mandatory=$true)][string]$AppDir,
    [Parameter(Mandatory=$true)][string]$StageDir,
    [Parameter(Mandatory=$true)][string]$ExeName,
    [Parameter(Mandatory=$true)][int]$ParentPid
)

$ErrorActionPreference = "Stop"
$logDir = Join-Path $AppDir "logs"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$log = Join-Path $logDir "update_apply.log"

function Initialize-RotatingLog([string]$Path) {
    $root = [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($Path), [System.IO.Path]::GetFileNameWithoutExtension($Path))
    $ext = [System.IO.Path]::GetExtension($Path)
    $oldest = "$root.2$ext"
    if (Test-Path -LiteralPath $oldest) { Remove-Item -LiteralPath $oldest -Force -ErrorAction SilentlyContinue }
    $one = "$root.1$ext"
    if (Test-Path -LiteralPath $one) { Move-Item -LiteralPath $one -Destination $oldest -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $Path) { Move-Item -LiteralPath $Path -Destination $one -Force -ErrorAction SilentlyContinue }
}

Initialize-RotatingLog $log

function Write-UpdateLog([string]$Message) {
    $line = "$(Get-Date -Format o) $Message"
    Add-Content -LiteralPath $log -Value $line -Encoding UTF8
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "MS747 MCP Router Update"
$form.Width = 520
$form.Height = 180
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true

$title = New-Object System.Windows.Forms.Label
$title.Text = "Updating MS747 MCP Router"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$title.Left = 18
$title.Top = 18
$title.Width = 470
$title.Height = 28
$form.Controls.Add($title)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Preparing update..."
$status.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$status.Left = 18
$status.Top = 56
$status.Width = 470
$status.Height = 24
$form.Controls.Add($status)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Left = 18
$progress.Top = 88
$progress.Width = 470
$progress.Height = 22
$progress.Minimum = 0
$progress.Maximum = 100
$progress.Value = 0
$form.Controls.Add($progress)

$detail = New-Object System.Windows.Forms.Label
$detail.Text = "Please do not turn off your computer."
$detail.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$detail.Left = 18
$detail.Top = 118
$detail.Width = 470
$detail.Height = 20
$form.Controls.Add($detail)

function Set-UpdateStatus([string]$Message, [int]$Value) {
    Write-UpdateLog $Message
    $status.Text = $Message
    $progress.Value = [Math]::Max($progress.Minimum, [Math]::Min($progress.Maximum, $Value))
    [System.Windows.Forms.Application]::DoEvents()
}

function Set-FirmwareUpdateRequired {
    $userDataDir = Join-Path $AppDir "user_data"
    if (-not (Test-Path -LiteralPath $userDataDir)) {
        New-Item -ItemType Directory -Path $userDataDir | Out-Null
    }
    $statePath = Join-Path $userDataDir "app_state.json"
    $legacyStatePath = Join-Path $AppDir "app_state.json"
    if ((-not (Test-Path -LiteralPath $statePath)) -and (Test-Path -LiteralPath $legacyStatePath)) {
        Copy-Item -LiteralPath $legacyStatePath -Destination $statePath -Force
    }
    $versionPath = Join-Path $StageDir "app_version.json"
    $version = "unknown"

    try {
        if (Test-Path -LiteralPath $versionPath) {
            $versionData = Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($versionData.version) {
                $version = ([string]$versionData.version).TrimStart("v")
            }
        }
    } catch {
        Write-UpdateLog "Version read warning: $($_.Exception.Message)"
    }

    try {
        if (Test-Path -LiteralPath $statePath) {
            $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($null -eq $state) { $state = [pscustomobject]@{} }
        } else {
            $state = [pscustomobject]@{}
        }

        $state | Add-Member -NotePropertyName "firmware_update_required_after_update" -NotePropertyValue $true -Force
        $state | Add-Member -NotePropertyName "firmware_update_required_version" -NotePropertyValue $version -Force
        $state | Add-Member -NotePropertyName "firmware_update_required_set_time" -NotePropertyValue (Get-Date -Format o) -Force
        $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $statePath -Encoding UTF8
        Write-UpdateLog "Marked firmware update required for router v$version."
    } catch {
        Write-UpdateLog "App state write warning: $($_.Exception.Message)"
    }
}

try {
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()

    Set-UpdateStatus "Waiting for router to close..." 10
    try {
        Wait-Process -Id $ParentPid -Timeout 60 -ErrorAction SilentlyContinue
    } catch {
        Write-UpdateLog "Wait warning: $($_.Exception.Message)"
    }
    Start-Sleep -Milliseconds 700

    Set-UpdateStatus "Applying update files..." 25
    $preserve = @("user_data", "mapping.json", "router_config.json", "router_log.txt", "pmdg_comm_log.txt", "pmdg_bridge_log.txt", "logs", "app_state.json", ".github_token", "github_token.txt")
    $items = @(Get-ChildItem -LiteralPath $StageDir -Force)
    $copyItems = @($items | Where-Object { $preserve -notcontains $_.Name })
    $count = [Math]::Max(1, $copyItems.Count)
    $i = 0

    foreach ($item in $copyItems) {
        $i += 1
        $value = 25 + [int](($i / $count) * 55)
        Set-UpdateStatus "Copying $($item.Name)..." $value
        $dest = Join-Path $AppDir $item.Name
        if ($item.PSIsContainer) {
            if (Test-Path -LiteralPath $dest) {
                Remove-Item -LiteralPath $dest -Recurse -Force
            }
            Copy-Item -LiteralPath $item.FullName -Destination $dest -Recurse -Force
        } else {
            Copy-Item -LiteralPath $item.FullName -Destination $dest -Force
        }
    }

    Set-FirmwareUpdateRequired

    Set-UpdateStatus "Cleaning temporary files..." 85
    try {
        Remove-Item -LiteralPath $StageDir -Recurse -Force
    } catch {
        Write-UpdateLog "Stage cleanup warning: $($_.Exception.Message)"
    }

    $exe = Join-Path $AppDir $ExeName
    if (-not (Test-Path -LiteralPath $exe)) {
        throw "Executable not found after update: $exe"
    }

    Set-UpdateStatus "Restarting router..." 95
    Start-Process -FilePath $exe -WorkingDirectory $AppDir
    Set-UpdateStatus "Update complete." 100
    Start-Sleep -Milliseconds 900
    $form.Close()
} catch {
    Write-UpdateLog "Update failed: $($_.Exception.Message)"
    $status.Text = "Update failed."
    $detail.Text = $_.Exception.Message
    $progress.Value = 100
    [System.Windows.Forms.MessageBox]::Show(
        "Update failed.`n`n$($_.Exception.Message)`n`nSee logs\update_apply.log in the router folder.",
        "MS747 MCP Router Update",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}
