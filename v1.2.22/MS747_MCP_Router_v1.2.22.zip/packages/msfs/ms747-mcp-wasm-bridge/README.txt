MS747 MCP WASM Bridge

This Community package is installed by the MS747 MCP Router GUI.
It exposes a small LVar mailbox used by the router's MSFS Asobo 747-8i bridge.

Do not edit the files in this installed package directly. Update the router and
use Debug & Options -> MSFS WASM Bridge -> Install / Update WASM Bridge.
